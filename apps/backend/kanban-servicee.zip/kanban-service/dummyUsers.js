const users = [
  { name: 'Alice Johnson', dob: '1990-05-15', role: 'developer' },
  { name: 'Bob Smith', dob: '1988-11-22', role: 'collaborator' },
  { name: 'Charlie Brown', dob: '1995-07-09', role: 'project member' },
  { name: 'Diana Prince', dob: '1992-03-12', role: 'developer' },
  { name: 'Ethan Wright', dob: '1993-08-30', role: 'project manager' },
  { name: 'Fiona Davis', dob: '1991-01-19', role: 'collaborator' },
  { name: 'George Lee', dob: '1987-04-05', role: 'developer' },
  { name: 'Hannah Scott', dob: '1994-06-21', role: 'project member' },
  { name: 'Ian Clark', dob: '1989-09-13', role: 'project manager' },
  { name: 'Julia Adams', dob: '1996-11-02', role: 'developer' },
  { name: 'Kevin White', dob: '1990-12-28', role: 'collaborator' },
  { name: 'Laura Martinez', dob: '1993-03-15', role: 'project member' },
  { name: 'Michael Young', dob: '1986-07-17', role: 'developer' },
  { name: 'Nina Turner', dob: '1992-10-10', role: 'project manager' },
  { name: 'Oscar Hall', dob: '1985-02-09', role: 'collaborator' },
  { name: 'Paula Green', dob: '1997-08-14', role: 'project member' },
  { name: 'Quentin Brooks', dob: '1991-05-03', role: 'developer' },
  { name: 'Rachel Evans', dob: '1989-03-25', role: 'project manager' },
  { name: 'Steven King', dob: '1994-12-05', role: 'collaborator' },
  { name: 'Tina Morris', dob: '1995-06-30', role: 'project member' },
];

module.exports = users;
