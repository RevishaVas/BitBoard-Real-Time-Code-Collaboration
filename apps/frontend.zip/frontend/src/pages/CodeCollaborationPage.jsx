import React from 'react'

export default function CodeCollaborationPage() {
  return (
    <div>
      <h1>Code Collaboration</h1>
    </div>
  )
}
