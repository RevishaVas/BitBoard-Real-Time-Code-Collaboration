import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import CodeCollaborationPage from "./pages/CodeCollaborationPage";
import KanbanPage from "./pages/KanbanPage";
import ChatPage from "./pages/ChatPage";
import Layout from "./pages/Layout";

function App() {
  return (
     <div className="flex flex-col h-screen">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Navigate to="/kanban" />} />
          <Route element={<Layout />}>
            <Route index element={<CodeCollaborationPage />} />
            <Route path="code-collaboration" element={<CodeCollaborationPage />} />
            <Route path="kanban" element={<KanbanPage />} />
            <Route path="chat" element={<ChatPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
